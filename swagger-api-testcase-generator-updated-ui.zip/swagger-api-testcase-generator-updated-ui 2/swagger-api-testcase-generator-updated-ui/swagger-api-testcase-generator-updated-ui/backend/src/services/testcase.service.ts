import { ZodError } from "zod";
import type { ApiTestCase, JsonObject, TestCaseCategory } from "../types/index.js";
import { GroqTestCaseOutputSchema } from "../schemas/llm.schemas.js";
import { callGroqJson, isGroqEnabled } from "./groq.service.js";
import { TEST_CASE_SYSTEM_PROMPT } from "./prompts.js";
import { env } from "../config/environment.js";
import { logger } from "../utils/logger.js";
import { AppError } from "../utils/errors.js";

function deduplicate(cases: ApiTestCase[]): ApiTestCase[] {
  const seen = new Set<string>();
  return cases.filter((testCase) => {
    const key = `${testCase.method}|${testCase.endpoint}|${testCase.category}|${testCase.title.toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

const PRIORITY_RANK: Record<ApiTestCase["priority"], number> = { High: 0, Medium: 1, Low: 2 };

// Round-robins across categories (highest priority first within each) so the cap
// spreads across positive/negative/boundary/etc. instead of one category eating the
// whole budget. Cases within a category stay in spec order, which already alternates
// across endpoints, so endpoint coverage stays broad too.
function limitTestCases(cases: ApiTestCase[], max: number): ApiTestCase[] {
  if (cases.length <= max) return cases;

  const groups = new Map<string, ApiTestCase[]>();
  for (const testCase of cases) {
    const group = groups.get(testCase.category);
    if (group) group.push(testCase);
    else groups.set(testCase.category, [testCase]);
  }
  for (const group of groups.values()) {
    group.sort((a, b) => PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]);
  }

  const groupList = [...groups.values()];
  const selected: ApiTestCase[] = [];
  for (let round = 0; selected.length < max && round < Math.max(...groupList.map((g) => g.length)); round++) {
    for (const group of groupList) {
      if (selected.length >= max) break;
      if (round < group.length) selected.push(group[round]);
    }
  }
  return selected;
}

function renumber(cases: ApiTestCase[]): ApiTestCase[] {
  return cases.map((testCase, index) => ({ ...testCase, testCaseId: `TC-API-${String(index + 1).padStart(3, "0")}` }));
}

async function groqCases(specification: JsonObject, categories: TestCaseCategory[]) {
  const system = TEST_CASE_SYSTEM_PROMPT;
  const user = JSON.stringify({ categories, specification });
  const output = await callGroqJson(system, user);
  try {
    return GroqTestCaseOutputSchema.parse(output).testCases;
  } catch (error) {
    if (error instanceof ZodError) {
      logger.error({ issues: error.issues.slice(0, 10) }, "Groq output did not match the test-case schema.");
      throw new AppError(
        502,
        "GROQ_OUTPUT_INVALID",
        "Groq returned test cases that do not match the required schema.",
        { issues: error.issues.slice(0, 10) }
      );
    }
    throw error;
  }
}

function finalize(cases: ApiTestCase[]): ApiTestCase[] {
  return renumber(limitTestCases(deduplicate(cases), env.MAX_TEST_CASES));
}

// Test cases are generated exclusively by Groq (the LLM). There is intentionally no
// hardcoded/deterministic fallback: if Groq is not configured or the request fails,
// generation errors out so the application never returns non-LLM results.
export async function generateTestCases(specification: JsonObject, categories: TestCaseCategory[]) {
  if (!isGroqEnabled()) {
    throw new AppError(
      503,
      "GROQ_NOT_CONFIGURED",
      "Groq is not configured. Set GROQ_API_KEY and GROQ_MODEL in the backend .env to generate test cases."
    );
  }

  const generated = await groqCases(specification, categories);
  if (generated.length === 0) {
    throw new AppError(502, "GROQ_EMPTY_RESULT", "Groq returned no test cases for the supplied specification.");
  }

  logger.info({ count: generated.length, model: env.GROQ_MODEL }, "Generated test cases with Groq.");
  return { testCases: finalize(generated), source: "groq" as const, model: env.GROQ_MODEL };
}

export function summarizeTestCases(testCases: ApiTestCase[]) {
  const counts = Object.fromEntries([
    "positive", "negative", "boundary", "authentication", "authorization", "validation", "error-handling"
  ].map((category) => [category, testCases.filter((testCase) => testCase.category === category).length]));
  return { totalTestCases: testCases.length, ...counts };
}
