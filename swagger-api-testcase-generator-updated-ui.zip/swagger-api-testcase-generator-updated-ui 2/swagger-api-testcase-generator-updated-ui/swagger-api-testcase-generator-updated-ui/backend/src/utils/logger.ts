import pino from "pino";

export const logger = pino({
  level: process.env.NODE_ENV === "production" ? "info" : "debug",
  redact: {
    paths: ["req.headers.authorization", "GROQ_API_KEY", "apiKey"],
    censor: "[REDACTED]"
  }
});
